WIDTH = 960
HEIGTH = 600
FPS = 60
TILESIZE = 64

#weapon
weapon_data ={
    'hammer':{'cooldown':100, 'damage':15,'graphic':'assets\player\hammer.png'}
}