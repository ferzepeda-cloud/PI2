<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="PINO_2" tilewidth="32" tileheight="32" tilecount="9" columns="3">
 <image source="PINO_2.png" width="96" height="96"/>
</tileset>
